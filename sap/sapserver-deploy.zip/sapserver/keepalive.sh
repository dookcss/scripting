#!/bin/sh
BASEDIR="$(cd "$(dirname "$0")" && pwd)"
PIDFILE="$BASEDIR/sapserver.pid"

if [ -f "$PIDFILE" ]; then
    PID=$(cat "$PIDFILE")
    if kill -0 "$PID" 2>/dev/null; then
        exit 0
    fi
fi

"$BASEDIR/start.sh"
