#!/bin/sh
BASEDIR="$(cd "$(dirname "$0")" && pwd)"
PIDFILE="$BASEDIR/sapserver.pid"

if [ -f "$PIDFILE" ]; then
    PID=$(cat "$PIDFILE")
    if kill -0 "$PID" 2>/dev/null; then
        kill "$PID"
        echo "sapserver stopped (PID: $PID)"
    fi
    rm -f "$PIDFILE"
else
    pkill -f "sapserver -listen" || true
    echo "sapserver stopped"
fi
