# sapserver 远端 SAP 签名微服务部署包

专为 `ipa-downloader` 配套设计的独立 Apple SAP 签名微服务。基于 Unicorn 引擎模拟 Apple CoreFP 例程，为登录请求生成 `X-Apple-ActionSignature` 签名。

---

## 📁 目录结构

```
sapserver/
├── README.md               # 本部署说明文档
├── start.sh                # 启动脚本（含端口、Token 与动态库加载配置）
├── stop.sh                 # 停止服务脚本
├── keepalive.sh            # 进程保活脚本（用于 crontab 定时探测）
├── sapserver               # FreeBSD amd64 预编译二进制程序
├── libunicorn.so.2         # FreeBSD 下编译的 Unicorn 2.1.4 引擎库
└── src/                    # 完整 Go 源码工程
    ├── cmd/sapserver/      # 服务端核心实现
    │   └── main.go         # HTTP 路由与并发签名会话管理
    ├── internal/sap/       # SAP 握手、CoreFP 模拟与签名核心包
    ├── pkg/                # 网络请求与工具支持包
    ├── go.mod / go.sum     # Go 依赖配置
    └── main.go             # 根入口
```

---

## 🚀 快速启动与运维

### 1. 赋予执行权限
```bash
chmod +x start.sh stop.sh keepalive.sh sapserver libunicorn.so.2
```

### 2. 配置端口与鉴权 Token
打开 `start.sh`，按需修改：
- `PORT`：服务监听端口（默认 `15581`）。
- `SAPSERVER_TOKEN`：客户端访问所需的 Bearer Token（若留空则为免鉴权公共模式）。

### 3. 启动 / 停止 / 状态检查
```bash
./start.sh              # 启动服务
./stop.sh               # 停止服务
./keepalive.sh          # 保活检测（未运行则拉起）
tail -f sapserver.log   # 查看运行日志
```

### 4. 设置自动保活与开机自启（以 crontab 为例）
```bash
(crontab -l 2>/dev/null; echo "*/10 * * * * $HOME/sapserver/keepalive.sh >/dev/null 2>&1") | crontab -
(crontab -l 2>/dev/null; echo "@reboot $HOME/sapserver/start.sh >/dev/null 2>&1") | crontab -
```

---

## 🛠️ 自行编译说明（如在其他 Linux/macOS 环境部署）

### 依赖环境
- Go 1.22+
- Unicorn 2.x 引擎库与头文件（`libunicorn.so` / `libunicorn.dylib`）

### 编译命令
```bash
cd src
go build -o ../sapserver ./cmd/sapserver
```

---

## 📡 API 接口契约

1. `GET /healthz`
   - 公开健康探针，返回服务运行状态、并发数与签名总数。
2. `POST /v1/session`
   - 与客户端单次登录生命周期绑定，建立专属 SAP Signer 会话。
   - 请求体：`{"setupUrl": "...", "certificateUrl": "...", "version": 200, "machineId": "<base64>"}`
   - 响应体：`{"sessionId": "..."}`
3. `POST /v1/session/{id}/sign`
   - 对待签名数据执行 CoreFP 签名。
   - 请求体：`{"data": "<base64>"}`
   - 响应体：`{"signature": "<base64>"}`
4. `DELETE /v1/session/{id}`
   - 释放并销毁该 SAP 签名会话。
