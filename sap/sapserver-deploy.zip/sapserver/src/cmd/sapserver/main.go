// cmd/sapserver：独立的 SAP 远端签名 HTTP 微服务。
// 每次签名建立全新的 SAP 会话（One-Time Session）与 Apple 握手，签完即销毁，
// 严格遵守 Apple App Store 登录协议对 SAP 会话单次消费的生命周期要求。
package main

import (
	"context"
	"crypto/rand"
	"crypto/subtle"
	"encoding/base64"
	"encoding/hex"
	"encoding/json"
	"flag"
	"log"
	"net/http"
	"os"
	"os/signal"
	"strings"
	"sync"
	"syscall"
	"time"

	"github.com/majd/ipatool/v2/internal/sap"
)

const (
	maxBodyBytes = 2 << 20 // 2 MiB
	maxDataBytes = 1 << 20 // 1 MiB
)

type signRequest struct {
	SetupURL       string `json:"setupUrl"`
	CertificateURL string `json:"certificateUrl"`
	Version        int    `json:"version"`
	MachineID      string `json:"machineId"` // base64
	Data           string `json:"data"`      // base64（兼容一次性 /v1/sign）
}

type sessionSignRequest struct {
	Data string `json:"data"` // base64
}

type sessionResponse struct {
	SessionID string `json:"sessionId"`
}

type signResponse struct {
	Signature string `json:"signature"` // base64
}

type errorResponse struct {
	Error string `json:"error"`
	Code  string `json:"code"`
}

type signerSession struct {
	signer   sap.ActionSigner
	lastUsed time.Time
}

type server struct {
	token         string
	sem           chan struct{} // signer 创建并发限制
	createTimeout time.Duration
	mu            sync.Mutex
	totalSigned   uint64
	inflight      int
	sessions      map[string]*signerSession
}

func writeError(w http.ResponseWriter, status int, code, msg string) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(status)
	_ = json.NewEncoder(w).Encode(errorResponse{Error: msg, Code: code})
}

func (s *server) authorize(r *http.Request) bool {
	if s.token == "" {
		return true
	}

	auth := r.Header.Get("Authorization")
	if !strings.HasPrefix(auth, "Bearer ") {
		return false
	}

	provided := strings.TrimPrefix(auth, "Bearer ")
	return subtle.ConstantTimeCompare([]byte(provided), []byte(s.token)) == 1
}

func newSessionID() (string, error) {
	buf := make([]byte, 24)
	if _, err := rand.Read(buf); err != nil {
		return "", err
	}
	return hex.EncodeToString(buf), nil
}

func decodeConfig(req signRequest) (sap.Config, error) {
	machineID, err := base64.StdEncoding.DecodeString(req.MachineID)
	if err != nil || len(machineID) == 0 || len(machineID) > 20 {
		return sap.Config{}, &argumentError{"machineId must be 1..20 bytes base64"}
	}

	version := req.Version
	if version == 0 {
		version = 200
	}

	return sap.Config{
		SetupURL:       req.SetupURL,
		CertificateURL: req.CertificateURL,
		Version:        uint32(version),
		HardwareID:     machineID,
	}, nil
}

type argumentError struct{ message string }
func (e *argumentError) Error() string { return e.message }

func (s *server) createSigner(ctx context.Context, config sap.Config) (sap.ActionSigner, error) {
	select {
	case s.sem <- struct{}{}:
		defer func() { <-s.sem }()
	case <-ctx.Done():
		return nil, ctx.Err()
	}

	createCtx, cancel := context.WithTimeout(ctx, s.createTimeout)
	defer cancel()
	return sap.NewSigner(createCtx, config)
}

// POST /v1/session：创建一个与整次 App Store Login 生命周期一致的 SAP signer。
func (s *server) handleCreateSession(w http.ResponseWriter, r *http.Request) {
	if !s.authorize(r) {
		writeError(w, http.StatusUnauthorized, "unauthorized", "invalid bearer token")
		return
	}
	if r.Method != http.MethodPost {
		writeError(w, http.StatusMethodNotAllowed, "method_not_allowed", "use POST")
		return
	}

	r.Body = http.MaxBytesReader(w, r.Body, maxBodyBytes)
	var req signRequest
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		writeError(w, http.StatusBadRequest, "invalid_json", err.Error())
		return
	}
	config, err := decodeConfig(req)
	if err != nil {
		writeError(w, http.StatusBadRequest, "invalid_arguments", err.Error())
		return
	}

	signer, err := s.createSigner(r.Context(), config)
	if err != nil {
		log.Printf("sap session handshake error: %v", err)
		writeError(w, http.StatusBadGateway, "signer_error", err.Error())
		return
	}
	id, err := newSessionID()
	if err != nil {
		_ = signer.Close()
		writeError(w, http.StatusInternalServerError, "session_error", err.Error())
		return
	}

	s.mu.Lock()
	s.sessions[id] = &signerSession{signer: signer, lastUsed: time.Now()}
	s.mu.Unlock()

	w.Header().Set("Content-Type", "application/json")
	_ = json.NewEncoder(w).Encode(sessionResponse{SessionID: id})
}

// POST /v1/session/{id}/sign；DELETE /v1/session/{id}
func (s *server) handleSession(w http.ResponseWriter, r *http.Request) {
	if !s.authorize(r) {
		writeError(w, http.StatusUnauthorized, "unauthorized", "invalid bearer token")
		return
	}

	path := strings.TrimPrefix(r.URL.Path, "/v1/session/")
	parts := strings.Split(strings.Trim(path, "/"), "/")
	if len(parts) == 0 || parts[0] == "" {
		writeError(w, http.StatusNotFound, "session_not_found", "missing session id")
		return
	}
	id := parts[0]

	if r.Method == http.MethodDelete && len(parts) == 1 {
		s.mu.Lock()
		session := s.sessions[id]
		delete(s.sessions, id)
		s.mu.Unlock()
		if session != nil {
			_ = session.signer.Close()
		}
		w.WriteHeader(http.StatusNoContent)
		return
	}

	if r.Method != http.MethodPost || len(parts) != 2 || parts[1] != "sign" {
		writeError(w, http.StatusMethodNotAllowed, "method_not_allowed", "use POST /v1/session/{id}/sign or DELETE /v1/session/{id}")
		return
	}

	s.mu.Lock()
	session := s.sessions[id]
	if session != nil {
		session.lastUsed = time.Now()
	}
	s.mu.Unlock()
	if session == nil {
		writeError(w, http.StatusNotFound, "session_not_found", "SAP signer session not found or expired")
		return
	}

	r.Body = http.MaxBytesReader(w, r.Body, maxBodyBytes)
	var req sessionSignRequest
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		writeError(w, http.StatusBadRequest, "invalid_json", err.Error())
		return
	}
	data, err := base64.StdEncoding.DecodeString(req.Data)
	if err != nil || len(data) == 0 || len(data) > maxDataBytes {
		writeError(w, http.StatusBadRequest, "invalid_arguments", "data must be non-empty base64 under 1MB")
		return
	}

	signature, err := session.signer.Sign(data)
	if err != nil {
		writeError(w, http.StatusBadGateway, "sign_error", err.Error())
		return
	}
	s.mu.Lock()
	s.totalSigned++
	s.mu.Unlock()

	w.Header().Set("Content-Type", "application/json")
	_ = json.NewEncoder(w).Encode(signResponse{Signature: base64.StdEncoding.EncodeToString(signature)})
}

func (s *server) cleanupExpiredSessions(maxIdle time.Duration) {
	ticker := time.NewTicker(time.Minute)
	defer ticker.Stop()
	for range ticker.C {
		cutoff := time.Now().Add(-maxIdle)
		var expired []*signerSession
		s.mu.Lock()
		for id, session := range s.sessions {
			if session.lastUsed.Before(cutoff) {
				expired = append(expired, session)
				delete(s.sessions, id)
			}
		}
		s.mu.Unlock()
		for _, session := range expired {
			_ = session.signer.Close()
		}
	}
}

func (s *server) handleSign(w http.ResponseWriter, r *http.Request) {
	if !s.authorize(r) {
		writeError(w, http.StatusUnauthorized, "unauthorized", "invalid bearer token")
		return
	}

	if r.Method != http.MethodPost {
		writeError(w, http.StatusMethodNotAllowed, "method_not_allowed", "use POST")
		return
	}

	r.Body = http.MaxBytesReader(w, r.Body, maxBodyBytes)

	var req signRequest
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		writeError(w, http.StatusBadRequest, "invalid_json", err.Error())
		return
	}

	machineID, err := base64.StdEncoding.DecodeString(req.MachineID)
	if err != nil || len(machineID) == 0 || len(machineID) > 20 {
		writeError(w, http.StatusBadRequest, "invalid_arguments", "machineId must be 1..20 bytes base64")
		return
	}

	data, err := base64.StdEncoding.DecodeString(req.Data)
	if err != nil || len(data) == 0 || len(data) > maxDataBytes {
		writeError(w, http.StatusBadRequest, "invalid_arguments", "data must be non-empty base64 under 1MB")
		return
	}

	version := req.Version
	if version == 0 {
		version = 200
	}

	config := sap.Config{
		SetupURL:       req.SetupURL,
		CertificateURL: req.CertificateURL,
		Version:        uint32(version),
		HardwareID:     machineID,
	}

	// 并发限流控制
	select {
	case s.sem <- struct{}{}:
		defer func() { <-s.sem }()
	case <-r.Context().Done():
		writeError(w, http.StatusRequestTimeout, "cancelled", "request cancelled while waiting")
		return
	}

	s.mu.Lock()
	s.inflight++
	s.mu.Unlock()

	defer func() {
		s.mu.Lock()
		s.inflight--
		s.mu.Unlock()
	}()

	ctx, cancel := context.WithTimeout(r.Context(), s.createTimeout)
	defer cancel()

	started := time.Now()
	signer, err := sap.NewSigner(ctx, config)
	if err != nil {
		log.Printf("sap handshake error: %v", err)
		writeError(w, http.StatusBadGateway, "signer_error", err.Error())
		return
	}
	defer func() {
		_ = signer.Close()
	}()

	signature, err := signer.Sign(data)
	if err != nil {
		log.Printf("sign error: %v", err)
		writeError(w, http.StatusBadGateway, "sign_error", err.Error())
		return
	}

	s.mu.Lock()
	s.totalSigned++
	s.mu.Unlock()

	log.Printf("signed successfully (session fresh) elapsed=%s dataLen=%d sigLen=%d",
		time.Since(started).Round(time.Millisecond), len(data), len(signature))

	w.Header().Set("Content-Type", "application/json")
	_ = json.NewEncoder(w).Encode(signResponse{
		Signature: base64.StdEncoding.EncodeToString(signature),
	})
}

func (s *server) handleHealthz(w http.ResponseWriter, _ *http.Request) {
	s.mu.Lock()
	signed := s.totalSigned
	inflight := s.inflight
	sessionCount := len(s.sessions)
	s.mu.Unlock()

	w.Header().Set("Content-Type", "application/json")
	_ = json.NewEncoder(w).Encode(map[string]any{
		"status":      "ok",
		"mode":        "stateful-login-session",
		"totalSigned": signed,
		"inflight":    inflight,
		"sessions":    sessionCount,
	})
}

func main() {
	var (
		addr          = flag.String("listen", "0.0.0.0:8080", "listen address")
		token         = flag.String("token", "", "bearer token required from clients (env: SAPSERVER_TOKEN)")
		concurrency   = flag.Int("concurrency", 4, "maximum concurrent SAP handshakes")
		maxSigners    = flag.Int("max-signers", 4, "compatibility alias for concurrency")
		createTimeout = flag.Duration("timeout", 2*time.Minute, "timeout for SAP handshake and signing")
		legacyTimeout = flag.Duration("create-timeout", 2*time.Minute, "compatibility alias for timeout")
		_             = flag.Duration("idle-timeout", 10*time.Minute, "ignored (fresh-session mode)")
	)
	flag.Parse()

	if *maxSigners != 4 && *concurrency == 4 {
		*concurrency = *maxSigners
	}
	if *legacyTimeout != 2*time.Minute && *createTimeout == 2*time.Minute {
		*createTimeout = *legacyTimeout
	}

	if *token == "" {
		*token = os.Getenv("SAPSERVER_TOKEN")
	}

	srv := &server{
		token:         *token,
		sem:           make(chan struct{}, *concurrency),
		createTimeout: *createTimeout,
		sessions:      make(map[string]*signerSession),
	}
	go srv.cleanupExpiredSessions(10 * time.Minute)

	mux := http.NewServeMux()
	mux.HandleFunc("/healthz", srv.handleHealthz)
	mux.HandleFunc("/v1/sign", srv.handleSign)
	mux.HandleFunc("/v1/session", srv.handleCreateSession)
	mux.HandleFunc("/v1/session/", srv.handleSession)

	httpServer := &http.Server{
		Addr:              *addr,
		Handler:           mux,
		ReadHeaderTimeout: 10 * time.Second,
	}

	log.Printf("sapserver listening on %s (stateful-login-session mode, concurrency=%d, auth=%v)",
		*addr, *concurrency, *token != "")

	go func() {
		if err := httpServer.ListenAndServe(); err != nil && err != http.ErrServerClosed {
			log.Fatalf("server error: %v", err)
		}
	}()

	sigChan := make(chan os.Signal, 1)
	signal.Notify(sigChan, os.Interrupt, syscall.SIGTERM)
	<-sigChan

	log.Printf("shutting down sapserver...")
	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()
	_ = httpServer.Shutdown(ctx)
}
