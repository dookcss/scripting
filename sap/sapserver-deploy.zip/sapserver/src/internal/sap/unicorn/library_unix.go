//go:build darwin || linux || freebsd

package unicorn

import (
	"context"
	"fmt"
	"os"
	"path/filepath"

	"github.com/ebitengine/purego"
)

func openLibrary(ctx context.Context) (library, error) {
	var libPath string

	if custom := os.Getenv("UNICORN_LIB_PATH"); custom != "" {
		if _, err := os.Stat(custom); err == nil {
			libPath = custom
		}
	}

	if libPath == "" {
		if execPath, err := os.Executable(); err == nil {
			sibling := filepath.Join(filepath.Dir(execPath), "libunicorn.so.2")
			if _, err := os.Stat(sibling); err == nil {
				libPath = sibling
			}
		}
	}

	if libPath == "" {
		paths, err := cachedRuntimePaths(ctx)
		if err != nil {
			return library{}, err
		}
		libPath = paths.library
	}

	if err := ctx.Err(); err != nil {
		return library{}, fmt.Errorf("load Unicorn library: %w", err)
	}

	handle, err := purego.Dlopen(libPath, purego.RTLD_NOW|purego.RTLD_LOCAL)
	if err != nil {
		return library{}, fmt.Errorf("%s: %w", libPath, err)
	}

	return library{
		handle: handle,
		close: func() error {
			return purego.Dlclose(handle)
		},
	}, nil
}
