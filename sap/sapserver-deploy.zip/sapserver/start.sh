#!/bin/sh
BASEDIR="$(cd "$(dirname "$0")" && pwd)"
PIDFILE="$BASEDIR/sapserver.pid"
LOGFILE="$BASEDIR/sapserver.log"

# 配置监听端口（默认 15581，支持环境变量传入）
PORT="${PORT:-15581}"

# 配置鉴权 Token（如不需要鉴权，请注释本行或留空）
export SAPSERVER_TOKEN="${SAPSERVER_TOKEN:-scripting}"

# 加载当前目录下的动态链接库（Unicorn 引擎 libunicorn.so.2）
export LD_LIBRARY_PATH="$BASEDIR:$LD_LIBRARY_PATH"

if [ -f "$PIDFILE" ]; then
    PID=$(cat "$PIDFILE")
    if kill -0 "$PID" 2>/dev/null; then
        echo "sapserver is already running (PID: $PID)"
        exit 0
    fi
fi

cd "$BASEDIR"
nohup ./sapserver -listen "0.0.0.0:$PORT" >> "$LOGFILE" 2>&1 &
echo $! > "$PIDFILE"
echo "sapserver started (PID: $!, Port: $PORT, Token: ${SAPSERVER_TOKEN:-none})"
